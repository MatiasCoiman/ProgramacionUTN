# Clase 25

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Creacion_biblioteca_lista_II.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=3m9wXd8FmR4&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV&index=25

### Ejercicio
#### Objetivo:

Agregar a la biblioteca la posibilidad de crear m�s de una lista

- Version: 0.1 del 07 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*  Array de punteros a estructuras creadas en forma din�mica