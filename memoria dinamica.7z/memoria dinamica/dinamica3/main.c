#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main()
{

    int* vec;
    int* aux;
    int i;
    vec = (int*) malloc (TAM* sizeof(int));

    if(vec == NULL)
    {
        printf("\n No se pudo conseguir memoria \n\n");
        system("pause");
        exit(1);
    }
    for( i = 0 ; i< TAM; i++)
    {
        printf("Ingrese un numero: ");
        scanf("%d ", vec + i);

    }
    for(i = 0; i < TAM; i++)
    {
        printf("%d", *(vec + i ) );
    }
    printf("\n\n");

    aux = (int*) realloc(vec,(TAM+5)* sizeof(int));//agranda la memoria de la array.

    if( aux == NULL)
    {
        printf("No se pudo conseguir memoria \n\n");
    }else
    {   vec= aux;
        for(int i = 5 ; i< (TAM+5); i++)
        {
            printf("Ingrese un numero: ");
            scanf("%d ", vec + i);
        }
        for(i = 0; i < (TAM+5); i++)
        {
            printf("%d", *(vec + i ) );
        }
    printf("\n\n");

    }

    vec= (int*) realloc (vec, TAM * sizeof(int));
     for(i = 0; i < TAM; i++)
    {
        printf("%d", *(vec + i ) );
    }

    free(vec);
    return 0;
}
