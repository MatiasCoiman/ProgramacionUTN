#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* pNum;


    pNum=(int*) malloc(sizeof(int));

    if(pNum == NULL)
    {
        printf("\nNo se pudo conseguir memoria. El programa finaliza \n\n");
        exit(1);
    }
    printf("Ingrese un numero: ");
    scanf("%d",pNum);
    //12*pNum=5;
    printf(" %d \n\n", *pNum);
    free(pNum);//libera el espacio, siempre hay que liberar la memoria en memoria dinamica
    return 0;
}
