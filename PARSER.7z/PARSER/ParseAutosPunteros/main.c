#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int id;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
    int estado;

}eAutos;


int main()
{
    FILE* f;
    int id;
    char marca[50];
    char modelo[50];
    char color[50];
    int anio;
    char anioCad[20];
    char idCad[20];
    int cant;
    eAutos* auto1;


    f= fopen("autos.csv", "r");
    if(f == NULL)
    {
        printf("No se pudo abir el archivo\n");
        exit(EXIT_FAILURE);
    }

     while(!feof(f))
    {
       cant = fscanf(f,"%[^,], %[^,], %[^,], %[^,], %[^\n]\n", idCad, marca, modelo, color, anioCad);


        if(cant != 5)
        {
            if(feof(f))
            {
                break;
            }
            else
            {
                printf("HUBO UN ERROR AL LEER EN EL ARCHIVO...");
                exit(EXIT_FAILURE);
            }



        }
        id=atoi(idCad);
        anio=atoi(anioCad);

        printf("%4d %14s %20s %16s %4d\n",id,marca,modelo,color,anio);
    }
    fclose(f);
    return 0;
}
