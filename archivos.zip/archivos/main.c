#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int legajo;
    char nombre[20];
    float sueldo;
    int estado;
}eEmpleado;


int main()
{




    printf("Hello world!\n");
    return 0;
}

eEmpleado* newEmpleado()
{
    eEmpleado* nuevoEmpleado;

    nuevoEmpleado= (eEmpleado*)malloc(sizeof(eEmpleado));
    if(nuevoEmpleado != NULL)
    {
     nuevoEmpleado->legajo=0;
     strcpy(nuevoEmpleado->nombre," ");
     nuevoEmpleado->sueldo=0;
     nuevoEmpleado->estado=0;
     }
     return nuevoEmpleado;
}

eEmpleado* newEmpleadoParam(int legajo, char nombre , float sueldo)
{

    eEmpleado* nuevoEmpleado;
    nuevoEmpleado* newEmpleado();

    if(nuevoEmpleado != NULL)
    {
     nuevoEmpleado->legajo=legajo;
     strcpy(nuevoEmpleado->nombre=nombre);
     nuevoEmpleado->sueldo=sueldo;
     nuevoEmpleado->estado=1;
     }
     return nuevoEmpleado;

}

void mostrarEmpleados(eEmpleado* vec[],int tam)
{

    if(vec != NULL && tam > 0)
    {
         for(int i=0;i<tam;i++)
        {
            if((vec+i)->estado==1)
                {
                    mostrarPersona(vec+i);
                }
        }
    }

}
void mostrarEmpleado(eEmpleado* vec)
{
    if(vec != NULL)
    {
        printf(" %d      %s       %.2f\n",(vec)->legajo,(vec)->nombre,(vec)->sueldo);
    }


}
void inicializarEmpleado(eEmpleado* vec, int tam)
{
    if(vec != NULL && tam >0)
    {
        int i;
    for(i=0;i<tam;i++)
        {
                    (vec+i)->estado=0;
        }
    }

}
eEmpleado* newArrayEmpleados(int tam)
{
    eEmpleado* array;

    if(tam > 0)
    {
        array = (eEmpleado*)malloc (tam* sizeof(eEmpleado));
        if(array!= NULL)
        {
            inicializarEmpleado(array, tam);
        }
    }
}
